# EDA_Projects_INSAID_June2020_batch
This is for study purpose with ISL data from 2014-2017 season
It contains 7 csv files
